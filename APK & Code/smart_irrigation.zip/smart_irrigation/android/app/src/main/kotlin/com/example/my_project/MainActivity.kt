package com.mycompany.smartirrigation

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
